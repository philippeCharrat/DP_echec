package view;

import javafx.scene.paint.Color;

public class CommandChangeWhiteColor implements Command {
	private Color couleur;

	public CommandChangeWhiteColor(Color couleur) {
		super();
		this.couleur = couleur;
	}

	@Override
	public void execute() {
		GuiConfig.whiteSquareColor.set(couleur);
	}

}
