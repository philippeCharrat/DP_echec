package view;

public class InvokerUndoRedo implements Conversation<Command> {

	@Override
	public void exec(Command cmd) {
		cmd.execute();
		
	}

	@Override
	public void undo() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void redo() {
		// TODO Auto-generated method stub
		
	}
	
}
