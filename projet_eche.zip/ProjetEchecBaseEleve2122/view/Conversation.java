package view;

public interface Conversation<C> {
	void exec(C cmd);
	void undo();
	void redo();
}