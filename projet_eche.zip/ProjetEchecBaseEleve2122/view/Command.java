package view;

public interface Command {

	void execute();
	
}
