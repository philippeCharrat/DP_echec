package view;

/**
 * @author francoise.perrin
 * Inspiration Jacques SARAYDARYAN, Adrien GUENARD *
 */
public enum PaintStyle {
	SOLID, GRADIENT
}
