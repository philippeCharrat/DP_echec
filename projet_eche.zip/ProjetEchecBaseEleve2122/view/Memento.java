package view;

import javafx.beans.property.ObjectProperty;
import javafx.scene.paint.Color;

public class Memento {
    private Color whiteColor;
    private Color blackColor;
    private PaintStyle texture;

    public Memento() 
    {
    	this.blackColor = GuiConfig.blackSquareColor.getValue();
    	this.whiteColor = GuiConfig.whiteSquareColor.getValue();
    	this.texture = GuiConfig.paintStyle.getValue();
    }
    
    public void changeMemento() 
    {
    	this.blackColor = GuiConfig.blackSquareColor.getValue();
    	this.whiteColor = GuiConfig.whiteSquareColor.getValue();
    	this.texture = GuiConfig.paintStyle.getValue();	
    }

    public void changeMemento(Color white, Color black, PaintStyle texture) 
    {
    	this.blackColor = black;
    	this.whiteColor = white;
    	this.texture = texture;	
    }

	public Color getWhiteColor() {
		return whiteColor;
	}

	public void setWhiteColor(Color whiteColor) {
		this.whiteColor = whiteColor;
	}

	public Color getBlackColor() {
		return blackColor;
	}

	public void setBlackColor(Color blackColor) {
		this.blackColor = blackColor;
	}

	public PaintStyle getTexture() {
		return texture;
	}

	public void setTexture(PaintStyle texture) {
		this.texture = texture;
	}
   
}