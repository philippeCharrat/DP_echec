package view;

import javafx.scene.Node;
import javafx.scene.layout.BorderPane;
import shared.GUICoord;

public class SquareGuiDecorator extends BorderPane implements ChessSquareGui {
	private SquareGui squareGui;
	
	public SquareGuiDecorator(SquareGui squareGui) {
		this.squareGui = squareGui;
		this.setCenter((Node) this.squareGui);
		GuiConfig.paintStyle.addListener((O,oldPs,newPs) ->this.paint());
		GuiConfig.blackSquareColor.addListener((O,oldPs,newPs) ->this.paint());
		GuiConfig.whiteSquareColor.addListener((O,oldPs,newPs) ->this.paint());		
	}
	
	@Override
	public GUICoord getCoord() {
		return squareGui.getCoord();
	}

	@Override
	public void resetColor(boolean isLight) {
		squareGui.resetColor(isLight);
	}

	@Override
	public void paint() {
		squareGui.paint();
	}

}
