package view;

public class CommandChangeTexture implements Command {
	private PaintStyle paintstyle;
	
	public CommandChangeTexture(PaintStyle paintstyle) {
		super();
		this.paintstyle = paintstyle;
	}

	@Override
	public void execute() {
		GuiConfig.paintStyle.set(this.paintstyle);
	}

}
