package view;

import javafx.scene.paint.Color;

public class CommandChangeBlackColor implements Command {

	private Color couleur;

	public CommandChangeBlackColor(Color couleur) {
		super();
		this.couleur = couleur;
	}

	@Override
	public void execute() {
		GuiConfig.blackSquareColor.set(couleur);
	}

}
