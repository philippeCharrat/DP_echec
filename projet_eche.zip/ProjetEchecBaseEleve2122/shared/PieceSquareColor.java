package shared;

/**
 * @author francoise.perrin
 * Inspiration Jacques SARAYDARYAN, Adrien GUENARD *
 */
public enum PieceSquareColor {
	WHITE, BLACK
}
