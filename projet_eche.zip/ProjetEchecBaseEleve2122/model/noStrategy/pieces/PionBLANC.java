package model.noStrategy.pieces;

import shared.ActionType;
import shared.ModelCoord;
import shared.PieceSquareColor;

public class PionBLANC extends  Pion  {

	public PionBLANC(PieceSquareColor pieceSquareColor, ModelCoord coord) {
		super(PieceSquareColor.WHITE, coord);
	}
	
	public boolean legitTakeMovement(int xFinal, int yFinal) {
		return (yFinal == this.getY()-1 && xFinal == this.getX()+1) || //test gauche
				(yFinal == this.getY()-1 && xFinal == this.getX()-1); // test droite
		
	}
	
	public boolean legitOnlyMovement(int xFinal, int yFinal) {
		return ((xFinal == this.getX()) && (Math.abs(yFinal - this.getY()) <= 1 ||  
				(Math.abs(yFinal - this.getY()) <= 2 && !this.hasMoved())) && 
				(yFinal - this.getY() < 0)); 
	}
}
