package model.noStrategy.pieces;

import shared.ModelCoord;
import shared.PieceSquareColor;

public class PionNOIR extends  Pion  {

	public PionNOIR(PieceSquareColor pieceSquareColor, ModelCoord coord) {
		super(PieceSquareColor.BLACK, coord);
	}
	
	public boolean legitTakeMovement(int xFinal, int yFinal) {
		return (yFinal == this.getY()+1 && xFinal == this.getX()+1) || 
				(yFinal == this.getY()+1 && xFinal == this.getX()-1); 
	}
	
	public boolean legitOnlyMovement(int xFinal, int yFinal) {
		return ((xFinal == this.getX()) && (Math.abs(yFinal - this.getY()) <= 1 ||  
				(Math.abs(yFinal - this.getY()) <= 2 && !this.hasMoved())) && 
				(yFinal - this.getY() > 0)); 
	}
	
}